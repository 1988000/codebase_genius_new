import os
import subprocess
from pathlib import Path
import json
import sys

def run_command(command):
    """Run shell command and return output or error."""
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Error: {e.stderr}")
        return None


def clone_repository(repo_url):
    """Clone a GitHub repository to the input folder."""
    input_path = Path.home() / "codebase_genius" / "input_repo"
    if input_path.exists():
        run_command(f"rm -rf {input_path}")  # Clean up old clone
    os.makedirs(input_path, exist_ok=True)

    print(f"🔍 Cloning repository from {repo_url}...")
    result = run_command(f"git clone {repo_url} {input_path}")
    if result is None:
        print("❌ Failed to clone repository.")
        return None
    print("✅ Repository cloned successfully!")
    return input_path


def run_analysis():
    """Run the Code Analyzer."""
    print("\n🔍 Running Code Analyzer...")
    run_command(f"python3 ~/codebase_genius/src/code_analyzer.py")


def run_docgenie():
    """Run DocGenie to generate Markdown documentation."""
    print("\n🪄 Generating documentation...")
    run_command(f"python3 ~/codebase_genius/src/doc_genie.py")


def display_results():
    """Display generated documentation."""
    output_path = Path.home() / "codebase_genius" / "output" / "DOCUMENTATION.md"
    if output_path.exists():
        print("\n📘 --- GENERATED DOCUMENTATION ---\n")
        with open(output_path, "r", encoding="utf-8") as f:
            print(f.read())
    else:
        print("⚠️ Documentation not found.")


if __name__ == "__main__":
    print("🤖 Welcome to Codebase Genius Supervisor!")
    repo_url = input("Enter a GitHub repository URL: ").strip()

    if not repo_url.startswith("https://github.com"):
        print("❌ Invalid URL. Please enter a valid GitHub repository link.")
        sys.exit(1)

    repo_path = clone_repository(repo_url)
    if repo_path:
        run_analysis()
        run_docgenie()
        display_results()

    print("\n✨ Workflow complete! Check the /output folder for your DOCUMENTATION.md file.")
